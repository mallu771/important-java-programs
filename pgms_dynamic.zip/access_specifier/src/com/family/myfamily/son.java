package com.family.myfamily;

public class son {
  public static void main(String[] args){
	  father f1=new father();
	 // f1.atm();
	  f1.car();
	  f1.bike();
	  f1.cycle();
  }
}
