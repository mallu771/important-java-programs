package com.family.myfamily;

public class father 
{
    private void atm()
    {
    	System.out.println("dad kaa atm");
    }
       void car()
       {
    	   System.out.println("dad kaa car");
       }
   protected void bike()
       {
    	   System.out.println("dad kaa bike");
       }
   public void cycle()
       {
    	   System.out.println("dad kaa cycle");
       }
}
