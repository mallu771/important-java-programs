package com.family.unclefamily;
import com.family.myfamily.father;
public class aunty extends father
{
  public static void main(String[] args)
  {
	  aunty a1= new aunty();
	     //a1.atm();
	    // a1.car();
	     a1.bike();
	     a1.cycle();
  }

}
