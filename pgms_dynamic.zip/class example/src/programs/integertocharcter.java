package programs;
import java.util.Scanner;
public class integertocharcter {
	public static void main(String[] args)
	{
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter number");
		int n1=sc.nextInt();
		int n2=sc.nextInt();
	    int n3=sc.nextInt();
	  inttochar(n1,n2,n3);
	  
	}
	static void inttochar(int n1,int n2,int n3)
	{
		for(int i=1;i<=26;i++){
			
		char ch=(char) (n1);
		char ch1=(char)(n2);
		
	System.out.println(ch+" "+ch1+" "+n3);
	       n1++;
	       n2++;
	       n3++;
		}	
}
}
