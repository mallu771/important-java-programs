package programs;
import java.util.Scanner;
public class fibonacy
  {
	 public static void main(String[] args)

	 {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter number:");
		int n=sc.nextInt();
		fib(n);
	 }
	 static void fib(int n)
	 {
		 int fib1=0;
		 int fib2=1;
		
		 System.out.print(fib1+" "+fib2);
		 for(int i=1;i<=n;i++)
		 {
			int fib3=fib1+fib2;
			fib1=fib2;
			fib2=fib3;
			System.out.print(" "+fib3);
		 }
		 
	 }
}
