package programs;
import java.util.Scanner; 
public class palin_string {
		public static void main(String[] args)
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter string");
			String str=sc.nextLine();
			reverse_str(str);
		}
		static void reverse_str(String str)
		{
			String rev="";
			for(int i=str.length()-1;i>=0;i--)
			{
				rev=rev+str.charAt(i);
			}
			if(str.equals(rev))
			{
				System.out.println(str+":is palindrome");
			}
			else
				System.out.println(str+":is not palinndrome");
		}
	}


