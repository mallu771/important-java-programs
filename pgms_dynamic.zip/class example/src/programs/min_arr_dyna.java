package programs;
import java.util.Scanner;
public class min_arr_dyna {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter size:");
		int size=sc.nextInt();
		int[] arr=new int[size];
		System.out.print("Enter arrays:");
		for(int i=0;i<arr.length;i++){
			arr[i]=sc.nextInt();
		}
		
		arr_min(arr);
		
	}
	static void arr_min(int[] arr){
	int min=arr[0];
	for(int i=1;i<arr.length-1;i++)
	{
		if(arr[i]<min){
			min=arr[i];
		}
	}
	System.out.println(min);
	}
}
