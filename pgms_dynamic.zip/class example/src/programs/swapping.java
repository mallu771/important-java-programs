package programs;
import java.util.Scanner;
public class swapping {
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter numbers:");
		int n1=sc.nextInt();
		int n2=sc.nextInt();
	swappe_num(n1,n2);
	}
	static void swappe_num(int n1, int n2)
	{
		int temp=n1;
		n1=n2;
		n2=temp;
		System.out.println(n1);
		System.out.println(n2);
	}
}
