package programs;
import java.util.Scanner;
 class factorial {
	public static void main(String[] args){
	 Scanner sc= new Scanner(System.in);
	 System.out.println("Enter number");
	 int n=sc.nextInt();
	int m= fact_n(n);
	 System.out.println(m);
	}
	static int fact_n(int n)
	{
		int fact=1;
		for(int i=n;i>=1;i--){
			fact=fact*i;
		}
			return fact;
		}
	}

