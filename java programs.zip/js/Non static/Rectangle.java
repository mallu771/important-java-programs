class Rectangle
{
  void area()
  {
    int w=6;
    int h=8;
    int res=w*h;
    System.out.println(res);
    }
    public static void main(String[] args)
    {

        new Rectangle().area();
	}
	}