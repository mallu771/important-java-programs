class parallelogram
{
  void area()
  {
    int b=6;
    int h=7;
    int res=b*h;
    System.out.println(res);
    }
    public static void main(String[] args)
    {

        new parallelogram().area();
	}
	}