class Trapezoid
{
  void area()
  {
    int a=6;
    int b=4;
    int h=5;
    double res=0.5*(a+b)*h;
    System.out.println(res);
    }
    public static void main(String[] args)
    {

        new Trapezoid().area();
	}
	}