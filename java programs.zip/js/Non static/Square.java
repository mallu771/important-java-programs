class Square
{
  void area()
  {
    int a=6;
    int res=a*a;
    System.out.println(res);
    }
    public static void main(String[] args)
    {

        new Square().area();
	}
	}