class Ellipse
{
  void area()
  {
    int a=6;
    int b=4;
    double res=3.142*a*b;
    System.out.println(res);
    }
    public static void main(String[] args)
    {

        new Ellipse().area();
	}
	}