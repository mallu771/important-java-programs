class Triangle
{
  void area()
  {
    int b=2;
    int h=5;
    double res=0.5*b*h;
    System.out.println(res);
    }
    public static void main(String[] args)
    {

        new Triangle().area();
	}
	}