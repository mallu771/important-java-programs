class phone_pay{
 void send_money(int phno){
 System.out.println("phonenumber");
 }
 void send_money(int acc_no,String ifsc){
 System.out.println("account number and ifsc code");
 }
  void send_money(String upi){
   System.out.println("upi numbers");
   }
   }
   class main_pay{
     public static void main(String[] args){
     phone_pay p=new phone_pay();
     p.send_money(8907);
     p.send_money(87822,"hdg672");
     p.send_money("jhds2344");
     }
     }