class teashop{
 void tea(int cost){
 System.out.println("tea cost");
 }
 void tea(String t_type){
 System.out.println("account number and ifsc code");
 }
  void tea(int no,String type){
   System.out.println("tea numbers and tea type");
   }
   }
   class main_tea{
     public static void main(String[] args){
    teashop t=new teashop();
    t.tea(8);
     t.tea("lemon");
     t.tea(1,"zera");
     }
     }