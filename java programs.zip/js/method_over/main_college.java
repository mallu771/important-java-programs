class college  {  
 static void admission(int no){
 System.out.println("admission no");
 }
 static void admission (String b_name){
 System.out.println( "branch name");
 }
  static void admission(int clg_fee,String exam){
   System.out.println("college fees and college exam");
   }
   }
   class main_college{
     public static void main(String[] args){
    college.admission(1);
    college.admission("cse");
    college.admission(18928,"wta");
    
     }
     }