class t2
{
	public static void main (String[] args)
	{
		int a=21;
		if(a>-9 && a<9)
		{
			System.out.println("its a single");
		}
		else
		{
			System.out.println("its not");
		}
	}
}