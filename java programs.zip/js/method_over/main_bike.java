class bike1{
 static void bike(int no){
 System.out.println("bike no");
 }
 static void bike(String b_name){
 System.out.println( "bike name");
 }
  static void bike(int no,String b_name){
   System.out.println("bike no and bike name");
   }
   }
   class main_bike{
     public static void main(String[] args){
    bike1.bike(888);
     bike1.bike("ns");
      bike1.bike(232,"ns1");
    
     }
     }