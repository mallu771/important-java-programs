
class t1
{public static void main (String[] args)
{
	
	String a="\"tamil\"";
	System.out.println(a);
}
}