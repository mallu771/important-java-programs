import java.util.Scanner;
class t4
{
	public static void main (String[] args)
	{
		Scanner sc= new Scanner(System.in);
		int a=sc.nextInt();
		int f1=0;
		int f2=1;
		int f3=0;
		System.out.println(f1+"     "+f2);
		for(int i=1; i<=a;i++)
		{
			f3=f1+f2;
			f3=f2;
			f2=f1;
			f1=f3;
			System.out.println(f3);
		}
	}
}