class t3
{
	public static void main (String[] args)
	{
		int a=-19;
		if(a<0)
		{
			a=a*-1;
			System.out.println(a);
		}
		else
		{
			System.out.println(a);
		}
	}
}