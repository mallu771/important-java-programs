class emp1{
 void emp(int emp_id){
 System.out.println("emp id");
 }
 void emp(String emp_name){
 System.out.println( "emp name");
 }
  void emp(int emp_id,String emp_name){
   System.out.println("emp id and emp name");
   }
   }
   class main_emp{
     public static void main(String[] args){
    emp1 e=new emp1();
    e.emp(8);
    e.emp("xyz");
    e.emp(1,"abc");
     }
     }