class play_store 
{  
 static void install(int no){
 System.out.println("app cost");
 }
 static void install(String app_name){
 System.out.println( "App name");
 }
  static void install(int no,String app){
   System.out.println("app cost and app name");
   }
   }
   class main_app{
     public static void main(String[] args){
    
play_store.install(25);
play_store.install("youtube");
play_store.install(30,"instagram");
    
     }
     }