class reference_print
{
 public static void main(String[] args)
 {
   Sample s1=new Sample();
   Sample s2=s1;
   System.out.println(s1);
   System.out.println(s2);
   }
   }