import java.util.Scanner;
class demo13
{
 
  static void str_rev(String str){
  String rev=" ";
  for(int i=str.length()-1;i>=0;i--){
    rev=rev+str.charAt(i);
    }
    System.out.println(rev);
 }
    public static void main(String[] args){
     Scanner sc=new Scanner(System.in);
     System.out.print("Enter name:");
       String str=sc.nextLine();
       str_rev(str);
	   System.out.print("Enter 2nd name:");
       String str1=sc.nextLine();
       str_rev(str1);
	   System.out.print("Enter 3nd name:");
       String str2=sc.nextLine();
       str_rev(str2);
     }

     }