class Swiggy
{
  static void selectPizza()
  {
   placeorder("veggi burg");
   }
 static void placeorder(String pizza)
 {
   System.out.println("order sucessfilly"+pizza);
   pizzaHut(pizza);
   }
  static void pizzaHut( String pizzaType)
  {

    cookandDespatch(pizzaType);
    }
    static String cookandDespatch(String pizzatocook)
    {
      System.out.println("pizza is reddy and dispatch");
      return "pizzatocook";

}


  public static void main(String[] arags)
  {
     selectPizza();
  }
  }