class demo113
	{
 public static void main(String[] args){
      int[]  a={4,5,1,3,2};
     int min=a[0];
	 int min2=0;
     for(int i=0;i<a.length;i++){
       if(a[i]<min){
		   min2=min;
          min=a[i];
	   }
		  else if(a[i]<min2)
          {
			min2=a[i];
			
          }
	
	  }
	  System.out.println(min2);
	  }
	  }
	