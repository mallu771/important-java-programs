class sample_array
{
  public static void main(String[] args)
  {  
    int[] arr={10,20,30,40,50};
  
System.out.println("************");
System.out.println("index\t values");
System.out.println("************");
for(int i=0;i<arr.length;i++)
	  {
	System.out.println(i+"\t"+arr[i]);
	  }


	}
  }
