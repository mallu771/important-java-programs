class Add
{
  void add()
  {
    int a=10;
    int b=30;
    int res=a+b;
    System.out.println(res);
    }

    public static void main(String[] args)
    {
      new Add().add();
      }
      }
