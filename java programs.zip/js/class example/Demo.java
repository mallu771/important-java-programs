class Demo 
{
  int a=10;
  void circle()
  {
     int b=4;
     int h=6;
     double res=0.5*b*h;
     System.out.println(res);
     }
     
     public static void main(String[] args)

   {
      new Demo().circle();
      System.out.println(new Demo().a);
      }
      }