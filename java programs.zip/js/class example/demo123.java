import java.util.Scanner;
class demo123
{
public static void main(String[] args)
{
Scanner sc = new Scanner(System.in);
System.out.println("enter number");
 int n=sc.nextInt();
 perfect_num(n);
 }
 static void perfect_num(int n)
 {
 int sum=0;
 for(int i=1;i<n;i++)
	 {
   if(n%i==0){
     sum=sum+i;
     }
     }
  if(sum==n){
    System.out.println(n+":perfect number");
    }
    else
        System.out.println(n+":Not perfect number");
	}
	}
   










