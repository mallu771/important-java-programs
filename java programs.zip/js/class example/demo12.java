class demo12
{
 static void str_rev(String str){
  String rev=" ";
  for(int i=str.length()-1;i>=0;i--){
    rev=rev+str.charAt(i);
    }
    System.out.println(rev);
 }
    public static void main(String[] args){
     
     str_rev("java");
	 str_rev("kannada");
	 str_rev("harsh");
     }
     }