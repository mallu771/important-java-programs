
import java.util.Scanner;
class rev_num4
{
  static void str_rev(String str){

 
   String rev="";
   for(int i=str.length()-1;i>=0;i--){

     rev=rev+str.charAt(i);
  
     }
       if(str.equals(rev)){
       System.out.println("palindrome:"+rev);
       }
       else{
          System.out.println(" Not palindrome:"+rev);
	   }
}
     public static void main(String[] args){
     Scanner sc=new Scanner(System.in);
      System.out.println("enter name");
      String str=sc.nextLine();
      str_rev(str);  
	
	  
     }
     }