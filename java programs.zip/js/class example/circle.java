class circle
{
  void area()
  {
    int r=10;
    
   double res=3.142*r*r;
    System.out.println(res);
    }

    public static void main(String[] args)
    {
      new circle().area();
      }
      }
