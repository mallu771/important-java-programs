

 class human {
	void emotions(){
		System.out.println("Some emotions");
	
	}
}
 class happy extends human {
	void emotions(){
		System.out.println("happy face");
	
	}
}
 class sad extends human {
	void emotions(){
		System.out.println("sad face");
	
	}
}
 class angry extends human {
	void emotions(){
		System.out.println("angry face");
	
	}
}
class situation {
	static void react(human h1)
	{
      h1.emotions();
	
	}
}
  class mainclass1
 {
	public static void main(String[] args){
		angry a1=new angry();
		happy h1=new happy();
		sad s1=new sad();
		situation.react(a1);
		situation.react(h1);
		situation.react(s1);
		
	}
}

