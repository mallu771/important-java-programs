class cdemo110
{
  public static void main(String[] args)
  {
     int[]  a={10,7,9,11,6,13,8,15,5,19};
     int min=a[0];
     for(int i=1;i<=a.length-1;i++){
       if(a[i]<min){
          min=a[i];
	  }
	  }
	  System.out.println(min);
	  }
	  }