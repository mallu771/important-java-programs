package programs;

class arr_factor {
	public static void main(String[] args)
	{
		int[] arr={121,146,421};
		for(int i=0;i<arr.length;i++)
		{
			int fact=1;
		
			while(arr[i]!=0)
			{
				int rem=arr[i]%10;
			
			for(int j=1;j<=rem;j++)
				
			{
				fact=fact*j;
			}
			}
			arr[i]=arr[i]/10;
		
			System.out.println(fact);
		
		}
	}}

