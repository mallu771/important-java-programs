class prime1
{
   public static void main(String[] args){
	   for(int k=1;k<=20;k++)
	   {
  
   int count=0;
      for(int i=1;i<=k;i++){
         if(k%i==0){
	 count++;
       }
       }
    if(count==2){
	System.out.println("prime");
	}
	else
	{
          System.out.println("Not prime");
	}
	   }
	}
	}