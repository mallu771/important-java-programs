class jspider 
{
  int java_mock;
  static String in_name="jspider";
  public static void main(String[] args)
  {
     System.out.println("Institute name:"+in_name);
     jspider j1=new jspider();
     j1.java_mock=1;
     System.out.println(j1.java_mock);
     jspider j2=new jspider();
     j2.java_mock=2;
     System.out.println(j2.java_mock);
     j2.java_mock=1;
     System.out.println(j2.java_mock);
}
}