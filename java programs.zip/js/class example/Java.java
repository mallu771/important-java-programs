class Java
{
  void mul()
  {
    int a=10;
    int b=30;
	int c=4;
    int res=a*b*c;
    System.out.println(res);
    }

    public static void main(String[] args)
    {
      new Java().mul();
      }
      }
