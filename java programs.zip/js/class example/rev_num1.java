
import java.util.Scanner;
class rev_num1
{
  static void rev_num(int n){

 
   int rev=0;
   while(n!=0){
     int rem=n%10;
     rev=(rev*10)+rem;
     n=n/10;
     }
     System.out.println(rev);
     }

     public static void main(String[] args){
     Scanner sc=new Scanner(System.in);
      System.out.println("enter number");
      int n=sc.nextInt();
      rev_num(n);  
	
	  
     }
     }