class Sample
{
  void add()
  {
     int a=2;
     int b=3;
     int res=a+b;
     System.out.println(res);
     }
     public static void main(String[] args)
     {
       new Sample().add();
       new Sample().add();
       new Sample().add();
       new Sample().add();
       }
       }