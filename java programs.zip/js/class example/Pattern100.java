class Pattern100 {
	
	public static void main(String[] args) 
		{
		int n=5;
		for (int i = 1; i < n; i++) {
     
      for (int j = 0; j < i; j++) {
        System.out.print(" ");
      }
     
      for (int k = (n - i) * 2 - 1; k >= 1; k--) {
        if (k == 1 || k == (n - i) * 2 - 1) {
          System.out.print("*");
        }
        else {
          System.out.print(" ");
        }
      }
      System.out.println();
    }
  }
}