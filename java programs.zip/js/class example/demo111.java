class demo111
{
  public static void main(String[] args)
  {
     int[]  a={10,7,9,11,6,13,8,15,5,19};
     int max=a[0];
     for(int i=1;i<=a.length-1;i++){
       if(a[i]>max){
          max=a[i];
	  }
	  }
	  System.out.println(max);
	  }
	  }