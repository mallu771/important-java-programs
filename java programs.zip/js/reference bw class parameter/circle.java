class test
{
  void area( int r)
  {
   
    double res=3.142*r*r;
    System.out.println(res);
    }
}
    class circle
    {
      public static void main(String[] args)
      {
        test t1=new test();
	      t1.area(5);
	   }
	   }
