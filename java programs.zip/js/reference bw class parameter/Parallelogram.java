class demo
{
  void area( int b,int h)
  {
   
    int res=b*h;
    System.out.println(res);
    }
}
    class Parallelogram
    {
      public static void main(String[] args)
      {
       demo d1=new demo();
	      d1.area(5,7);
	   }
	   }
