class tool
{
  void area( int a)
  {
   
    int res=a*a;
    System.out.println(res);
    }
}
    class Square
    {
      public static void main(String[] args)
      {
       tool t1=new tool();
	      t1.area(5);
	   }
	   }
