class test
{
  void area(int w,int h)
  {
    
    int res=w*h;
    System.out.println(res);
    }
}
    class Rectangle
    {
      public static void main(String[] args)
      {
       test t1=new test();
	      t1.area(4,8);
	   }
	   }
