class tester
{
  void area( int r)
  {
   
    double res=0.5*r*r*30.5;
    System.out.println(res);
    }
}
    class sector
    {
      public static void main(String[] args)
      {
        tester t1=new tester();
	      t1.area(5);
	   }
	   }
