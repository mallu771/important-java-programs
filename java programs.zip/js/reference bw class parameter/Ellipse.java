class demo
{
  void area( int a,int b)
  {
   
    double res=3.142*a*b;
    System.out.println(res);
    }
}
    class Ellipse
    {
      public static void main(String[] args)
      {
        demo d1=new demo();
	      d1.area(4,6);
	   }
	   }
