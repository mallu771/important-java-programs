class edit
{
  void area(int a,int b,int h)
  {
    
    double res=0.5*(a+b)*h;
    System.out.println(res);
    }
}
    class Trapezoid
    {
      public static void main(String[] args)
      {
       edit e1=new edit();
	      e1.area(4,6,8);
	   }
	   }
