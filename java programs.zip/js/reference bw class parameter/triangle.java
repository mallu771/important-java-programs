class Zc
{
  void area(int b,int h)
  {
    double res=0.5*b*h;
    System.out.println(res);
    }
}
    class triangle
    {
      public static void main(String[] args)
      {
        Zc z1=new Zc();
	      z1.area(4,6);
	   }
	   }
