class unversity
{
 void exam()
 {
   System.out.println("exam start");
   }
   }
   class college{
 public static void main(String[] args)
 {  
     unversity u1=new unversity();

    customer.need_exam(u1);
    }
    }
   
    class customer{
     static void need_exam(unversity u2){

     u2.exam();

   
   } }
