class apolo
{
 void medicine()
 {
   System.out.println("medicine for customer");
   }
   }
   class mediplus{
 public static void main(String[] args)
 {  
     apolo a1=new apolo();

    customer.need_medicine(a1);
    }
    }
   
    class customer{
     static void need_medicine(apolo a2){

     a2.medicine();

   
   } }
