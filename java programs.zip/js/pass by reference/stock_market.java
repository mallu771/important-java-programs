class stock_market
{
 void trading()
 {
   System.out.println("invest money");
   }
   }
   class upstock{
 public static void main(String[] args)
 {  
     stock_market s1=new stock_market();

    customer.need_money(s1);
    }
    }
   
    class customer{
     static void need_money(stock_market s2){

     s2.trading();

   
   } }
