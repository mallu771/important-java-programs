class train
{
 void ticket()
 {
   System.out.println("ticket book for train");
   }
   }
   class IRCTC{
 public static void main(String[] args)
 {  
     train t1=new train();

    customer.ticket_book(t1);
    }
    }
   
    class customer{
     static void ticket_book(train t2){

     t2.ticket();

   
   } }
