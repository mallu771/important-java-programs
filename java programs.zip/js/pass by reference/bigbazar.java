class holesales
{
 void product()
 {
   System.out.println("holesale project for customer");
   }
   }
   class bigbazar{
 public static void main(String[] args)
 {  
     holesales h1=new holesales();

   customer.need_product(h1);
    }
    }
   
    class customer{
     static void need_product(holesales h2){

    h2.product();

   
   } }
