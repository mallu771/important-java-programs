class Gmail
{
 void mails()
 {
   System.out.println("send messege");
   }
   }
   class comepos{
 public static void main(String[] args)
 {  
     Gmail g1=new Gmail();

    sender.messege(g1);
    }
    }
   
    class sender{
     static void messege(Gmail g2){

     g2.mails();

   
   } }
