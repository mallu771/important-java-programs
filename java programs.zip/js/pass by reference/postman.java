class post_office
{
 void letters()
 {
   System.out.println("give letters to customer");
   }
   }
   class postman{
 public static void main(String[] args)
 {  
    post_office p1=new post_office();

    customer.needletter(p1);
    }
    }
   
    class customer{
     static void needletter(post_office p2){

     p2.letters();

   
   } }
