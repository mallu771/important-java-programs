class cos
{
 void games()
 {
   System.out.println("playing games");
   }
   }
   class playstore{
 public static void main(String[] args)
 {  
     cos c1=new cos();

    player.install(c1);
    }
    }
   
    class player{
     static void install(cos c2){

     c2.games();

   
   } }
