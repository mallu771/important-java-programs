class book_house
{
 void books()
 {
   System.out.println("bookd available");
   }
   }
   class book_shop{
 public static void main(String[] args)
 {  
     book_house b1=new book_house();

    customer.need_book(b1);
    }
    }
   
    class customer{
     static void need_book(book_house b2){
     b2.book();

   
   } }
