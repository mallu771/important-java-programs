class sbi
{
 void amount()
 {
   System.out.println("sbi amount");
   }
   }
   class sbi_manager{
 public static void main(String[] args)
 {  
     sbi s1=new sbi();

    customer.return_amount(s1);
    }
    }
   
    class customer{
     static void return_amount(sbi s2){

     s2.amount();

   
   } }
