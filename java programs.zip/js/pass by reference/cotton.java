class clothes
{
 void dress()
 {
   System.out.println("wearing dress");
   }
   }
   class cotton{
 public static void main(String[] args)
 {  
     clothes c1=new clothes();

    customer.need_cloth(c1);
    }
    }
   
    class customer{
     static void need_cloth(clothes c2){

     c2.dress();

   
   } }
