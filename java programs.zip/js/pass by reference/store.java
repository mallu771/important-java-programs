class sumsung
{
 void product()
 {
   System.out.println("sumsung products");
   }
   }
   class store{
 public static void main(String[] args)
 {  
     sumsung s1=new sumsung();

    customer.needproduct(s1);
    }
    }
   
    class customer{
     static void needproduct(sumsung s2){

     s2.product();

   
   } }
