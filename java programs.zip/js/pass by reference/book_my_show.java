class movies
{
 void tickets()
 {
   System.out.println("book for movies");
   }
   }
   class book_my_show{
 public static void main(String[] args)
 {  
      movies m1=new movies();

   customer.need_tickets(m1);
    }
    }
   
    class customer{
     static void need_tickets( movies m2){

    m2.tickets();

   
   } }
