class Sample1
{
  static void area()
  {
    int a=4;
    int b=3;
    double res=3.142*a*b;
    System.out.println(res);
    }
    }
 class Ellipse
 {
    public static void main(String[] args)
    {
      Sample1.area();
      }
      }