class Demo
{
  static void area()
  {
    int w=6;
    int h=5;
    int res=w*h;
    System.out.println(res);
    }
    }
 class Rectangle
 {
    public static void main(String[] args)
    {
      Demo.area();
      }
      }