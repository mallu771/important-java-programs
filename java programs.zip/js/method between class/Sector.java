class plus
{
  static void area()
  {
    int r=5;
    double res=0.5*r*r*30.5;
    System.out.println(res);
   }
}
 class Sector
 {
    public static void main(String[] args)
    {
      plus.area();
      }
      }