class Sample1
{
  static void area()
  {
    int b=6;
    int h=8;
    int res=b*h;
    System.out.println(res);
   }
}
 class Parallelogram
 {
    public static void main(String[] args)
    {
      Sample1.area();
      }
      }