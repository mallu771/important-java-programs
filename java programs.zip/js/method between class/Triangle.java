class Sample
{
  static void area()
  {
    int b=5;
    int h=4;
    double res=0.5*b*h;
    System.out.println(res);
    }
    }
 class Triangle
 {
    public static void main(String[] args)
    {
      Sample.area();
      }
      }