class Sample
{
  static void area()
  {
    int a=5;
    int b=7;
    int h=6;
    double res=0.5*(a+b)*h;
    System.out.println(res);
    }
    }
 class Trapezoid
 {
    public static void main(String[] args)
    {
      Sample.area();
      }
      }