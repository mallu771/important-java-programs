class tester
{
  static void area()
  {
    int r=5;
    double res=3.142*r*r;
    System.out.println(res);
   }
}
 class Circle
 {
    public static void main(String[] args)
    {
      tester.area();
      }
      }