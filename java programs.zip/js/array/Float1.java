class Float1
{
  public static void main(String[] args)
  {
    float[] arr={15.0f,20.0f,25.0f,30.0f};
 
    System.out.println("**************");
    System.out.println("index \t value");
    System.out.println("**************");

    for(int i=0; i<=arr.length;i++)
    {  

      System.out.println(i+"\t"+arr[i]);
      }
      }
      }
