class Float
{
  public static void main(String[] args)
  {
    float[] arr= new float[4];
    arr[0]=10.0f;
    arr[1]=15.0f;
    arr[2]=20.0f;
    arr[3]=25.0f;
    System.out.println("**************");
    System.out.println("index \t value");
    System.out.println("**************");

    for(int i=0; i<=arr.length;i++)
    {  

      System.out.println(i+"\t"+arr[i]);
      }
      }
      }
