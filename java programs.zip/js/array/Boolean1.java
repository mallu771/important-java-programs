class Boolean1
{
  public static void main(String[] args)
  {
    boolean[] arr={true,false};
 
    System.out.println("**************");
    System.out.println("index \t value");
    System.out.println("**************");

    for(int i=0; i<=arr.length;i++)
    {  

      System.out.println(i+"\t"+arr[i]);
      }
      }
      }
