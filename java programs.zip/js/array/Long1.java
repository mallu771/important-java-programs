class Long1
{
  public static void main(String[] args)
  {
    long[] arr={45,50,55,60};
 
    System.out.println("**************");
    System.out.println("index \t value");
    System.out.println("**************");

    for(int i=0; i<=arr.length;i++)
    {  

      System.out.println(i+"\t"+arr[i]);
      }
      }
      }
