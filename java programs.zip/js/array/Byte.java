class Byte
{
  public static void main(String[] args)
  {
    byte[] arr= new byte[4];
    arr[0]=5;
    arr[1]=10;
    arr[2]=15;
    arr[3]=20;
    System.out.println("**************");
    System.out.println("index \t value");
    System.out.println("**************");

    for(int i=0; i<=arr.length;i++)
    {  

      System.out.println(i+"\t"+arr[i]);
      }
      }
      }
