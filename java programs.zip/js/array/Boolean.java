class Boolean
{
  public static void main(String[] args)
  {
    boolean[] arr= new boolean[2];
    arr[0]=true;
    arr[1]=false;
  
    System.out.println("**************");
    System.out.println("index \t value");
    System.out.println("**************");

    for(int i=0; i<=arr.length;i++)
    {  

      System.out.println(i+"\t"+arr[i]);
      }
      }
      }
