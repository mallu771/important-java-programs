class Double
{
  public static void main(String[] args)
  {
    double[] arr= new double[4];
    arr[0]=50.0;
    arr[1]=55.0;
    arr[2]=60.0;
    arr[3]=65.0;
    System.out.println("**************");
    System.out.println("index \t value");
    System.out.println("**************");

    for(int i=0; i<=arr.length;i++)
    {  

      System.out.println(i+"\t"+arr[i]);
      }
      }
      }
