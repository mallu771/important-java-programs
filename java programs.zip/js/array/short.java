class Short
{
  public static void main(String[] args)
  {
    short[] arr= new short[4];
    arr[0]=10;
    arr[1]=20;
    arr[2]=35;
    arr[3]=40;
    System.out.println("**************");
    System.out.println("index \t value");
    System.out.println("**************");

    for(int i=0; i<=arr.length;i++)
    {  

      System.out.println(i+"\t"+arr[i]);
      }
      }
      }
