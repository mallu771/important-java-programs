class Int
{
  public static void main(String[] args)
  {
    int[] arr= new int[4];
    arr[0]=15;
    arr[1]=20;
    arr[2]=30;
    arr[3]=35;
    System.out.println("**************");
    System.out.println("index \t value");
    System.out.println("**************");

    for(int i=0; i<=arr.length;i++)
    {  

      System.out.println(i+"\t"+arr[i]);
      }
      }
      }
