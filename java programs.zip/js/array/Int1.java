class Int1
{
  public static void main(String[] args)
  {
    int[] arr={25,30,35,40};
 
    System.out.println("**************");
    System.out.println("index \t value");
    System.out.println("**************");

    for(int i=0; i<=arr.length;i++)
    {  

      System.out.println(i+"\t"+arr[i]);
      }
      }
      }
