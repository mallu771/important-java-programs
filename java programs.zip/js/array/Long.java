class Long
{
  public static void main(String[] args)
  {
    long[] arr= new long[4];
    arr[0]=20;
    arr[1]=25;
    arr[2]=30;
    arr[3]=40;
    System.out.println("**************");
    System.out.println("index \t value");
    System.out.println("**************");

    for(int i=0; i<=arr.length;i++)
    {  

      System.out.println(i+"\t"+arr[i]);
      }
      }
      }
