class edit
{
  double area( )
  {
    int r=4;
    double res=3.142*r*r;
    return res;
    }
}
    class circle
    {
      public static void main(String[] args)
      {
        edit e1=new edit();
	      double B=e1.area();
        System.out.println(B);
	   }
	   }
