class test
{
  int area( )
  {
    int w=4;
    int h=6;
    int res=w*h;
    return res;
    }
}
    class rectangle
    {
      public static void main(String[] args)
      {
        test t1=new test();
	    int y=t1.area();
        System.out.println(y);
	   }
	   }
