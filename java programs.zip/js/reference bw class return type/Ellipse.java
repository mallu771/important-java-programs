class tester
{
  double area( )
  {
    int a=4;
    int b=5;
    double res=3.142*a*b;
    return res;
    }
}
    class Ellipse
    {
      public static void main(String[] args)
      {
        tester t1=new tester();
	     double m=t1.area();
        System.out.println(m);
	   }
	}
