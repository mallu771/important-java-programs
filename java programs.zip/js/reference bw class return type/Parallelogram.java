class test
{
  int area( )
  {
    int b=4;
    int h=7;
    int res=b*h;
    return res;
    }
}
    class Parallelogram
    {
      public static void main(String[] args)
      {
        test t1=new test();
	    int A=t1.area();
        System.out.println(A);
	   }
	   }
