class Sector
{
  static void area(int r,double t)
  {

     double res=0.5*r*r*t;
     System.out.println(res);
  }

  public static void main(String[] args)
  {

    area(5,30.5);
    }
}