class Circle
{
  static void area(int r)
  {
      double c=3.142*r*r;
     System.out.println(c);

    }
    public static void main(String[] args)
    {
      area(4);
      }
}
    