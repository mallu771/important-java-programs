class Trapezoid
{
  static void area(int a, int b, int h)
  {
      double c=0.5*(a+b)*h;
     System.out.println(c);

    }
    public static void main(String[] args)
    {
      area(4,6,8);
      }
      }
    