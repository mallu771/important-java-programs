class Sector
{
  static void area(int r)
  {
      double c=0.5*r*r*30.5;
     System.out.println(c);

    }
    public static void main(String[] args)
    {
      area(4);
      }
}