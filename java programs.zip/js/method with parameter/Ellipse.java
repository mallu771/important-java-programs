class Ellipse
{
  static void area(int a, int b)
  {
      double c=3.142*a*b;;
     System.out.println(c);

    }
    public static void main(String[] args)
    {
      area(4,6);
      }
      }
    