class Rectangle
{
  static void area(int w, int h)
  {
      int c=w*h;
     System.out.println(c);

    }
    public static void main(String[] args)
    {
      area(4,6);
      }
      }
    