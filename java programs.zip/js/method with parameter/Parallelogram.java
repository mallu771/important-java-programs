class Parallelogram
{
  static void area(int b, int h)
  {
      int c=b*h;
     System.out.println(c);

    }
    public static void main(String[] args)
    {
      area(4,6);
      }
      }
    