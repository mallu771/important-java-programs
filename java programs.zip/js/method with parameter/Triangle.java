class Triangle
{
  static void area(int b, int h)
  {
      double c=0.5*b*h;
     System.out.println(c);

    }
    public static void main(String[] args)
    {
      area(4,6);
      }
      }
    