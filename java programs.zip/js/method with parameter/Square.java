class Square
{
  static void area(int a)
  {
      int c=a*a;
     System.out.println(c);

    }
    public static void main(String[] args)
    {
      area(4);
      }
      }
    