class Insta
{
  static void signup()
  {
   System.out.println("Sigup Insta");
  }

   static void login()
  {
   System.out.println("login Insta");
   }

  public static void main(String[] args)
  {

    signup();
    login();
    homePage();
    logout();
    }

   static void homePage()
  {
   System.out.println("Insta home page");
   }

   static void logout()
  {
   System.out.println("logout Insta");
   }
}