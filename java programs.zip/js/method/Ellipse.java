class Ellipse
{

   static void area()
   {
     int a=10;
     int b=20;
     double res=3.142*a*b;
     System.out.println(res);
     }
     public static void main(String[] args)
     {
       area();
       }
       }