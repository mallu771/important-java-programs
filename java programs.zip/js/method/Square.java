class Square
{

  static void area()
  {
    
     int a=7;
     int res=a*a;
     System.out.println(res);

   }
   public static void main(String[] args)
   {area();
   }
   }
