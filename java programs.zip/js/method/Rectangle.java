class Rectangle
{
  static void area()
  {

     int w=7;
     int h=5;
     int res=w*h;
     System.out.println(res);

    }
    public static void main(String[] args)
    {

       area();
       }
       }