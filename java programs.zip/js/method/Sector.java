class Sector
{
  static void area()
  {

    int r=5;
    double res=0.5*r*r*30.5;
    System.out.println(res);

    }
    public static void main(String[] args)
    {  
      area();

      }
      }