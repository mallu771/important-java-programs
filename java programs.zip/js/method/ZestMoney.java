class ZestMoney
{
  static void signup()
  {
   System.out.println("Sigup ZestMoney");
  }

   static void login()
  {
   System.out.println("login  ZestMoney");
   }

  public static void main(String[] args)
  {

    signup();
    login();
    homePage();
    logout();
    }

   static void homePage()
  {
   System.out.println(" ZestMoney home page");
   }

  static void applyLoan()
  {
   System.out.println("Apply loan ZestMoney");
   }

   static void logout()
  {
   System.out.println("logout ZestMoney");
   }
}