class Pubg
{
  static void signup()
  {
   System.out.println("Sigup  Pubg");
  }

   static void login()
  {
   System.out.println("login  Pubg");
   }

  public static void main(String[] args)
  {

    signup();
    login();
    homePage();
    order();
    logout();
    }

   static void homePage()
  {
   System.out.println("  Pubg home page");
   }

   static void order()
  {
   System.out.println("order in  Pubg");
   }

   static void logout()
  {
   System.out.println("logout  Pubg");
   }
}