class Triangle
{
  static void area()
  {
  
    double b=5.3;
	double h=5.5;
    final double s=0.5;
    double res=s*b*h;
    System.out.println(res);
  }
 
 public static void main(String[] args)
 {

      area();
 }

}