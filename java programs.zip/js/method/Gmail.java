class Gmail
{
  static void signup()
  {
   System.out.println("Sigup Gmail");
  }

   static void login()
  {
   System.out.println("login Gmail");
   }

  public static void main(String[] args)
  {

    signup();
    login();
    homePage();
    logout();
    }

   static void homePage()
  {
   System.out.println("Gmail home page");
   }

   static void logout()
  {
   System.out.println("logout Gmail");
   }
}