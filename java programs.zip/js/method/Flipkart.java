class Flipkart
{
  static void signup()
  {
   System.out.println("Sigup Flipkart");
  }

   static void login()
  {
   System.out.println("login  Flipkart");
   }

  public static void main(String[] args)
  {

    signup();
    login();
    homePage();
    order();
    logout();
    }

   static void homePage()
  {
   System.out.println(" Flipkart home page");
   }

   static void order()
  {
   System.out.println("order in  Flipkart");
   }

   static void logout()
  {
   System.out.println("logout  Flipkart");
   }
}