class Facebook
{
  static void signup()
  {
   System.out.println("Sigup Facebook");
  }

   static void login()
  {
   System.out.println("login Facebook");
   }

  public static void main(String[] args)
  {

    signup();
    login();
    homePage();
    logout();
    }

   static void homePage()
  {
   System.out.println("Facebook home page");
   }

   static void logout()
  {
   System.out.println("logout Facebook");
   }
}