class Amazon
{
  static void signup()
  {
   System.out.println("Sigup Amazon");
  }

   static void login()
  {
   System.out.println("login Amazon");
   }

  public static void main(String[] args)
  {

    signup();
    login();
    homePage();
    order();
    logout();
    }

   static void homePage()
  {
   System.out.println("Amazon home page");
   }

   static void order()
  {
   System.out.println("order in Amazon");
   }

   static void logout()
  {
   System.out.println("logout Amazon");
   }
}