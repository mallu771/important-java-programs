class Parallelogram
{
  static void area()
  {
  int b=4;
  int h=5;
  int res=b*h;
  System.out.println(res);
  }

 public static void main(String[]args)
 {
  area();
  }
  }
