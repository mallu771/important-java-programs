class Zomato
{
  static void signup()
  {
   System.out.println("Sigup Zomato");
  }

   static void login()
  {
   System.out.println("login  Zomato");
   }

  public static void main(String[] args)
  {

    signup();
    login();
    homePage();
    order();
    logout();
    }

   static void homePage()
  {
   System.out.println(" Zomato home page");
   }

   static void order()
  {
   System.out.println("order in  Zomato");
   }

   static void logout()
  {
   System.out.println("logout  Zomato");
   }
}