class TRapezoid
{

  static void area()
  {

    int a=5;
    int b=6;
    int h =5;
    double res=0.5*(a+b)*h;
    System.out.println(res);
    }

    public static void main(String[] args)
    {
      area();
      }
      }