class Circle
{
  static void area()
  {

    int r=5;
    double res=3.142*r*r;
    System.out.println(res);
    }

    public static void main(String[] args)
    {
    area();
    }
   }