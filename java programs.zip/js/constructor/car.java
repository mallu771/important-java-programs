class car
{
   double cost;
   String m_name;
   String type;

   car(double x, String y, String z)
   {
     cost=x;
     m_name=y;
     type=z;
	
     }
     public static void main(String[] args)
     {
       car c1=new car(3000.00,"bmw","petrol");
         System.out.println(c1.cost);
		 System.out.println(c1.m_name);
		 System.out.println(c1.type);

     }
 }