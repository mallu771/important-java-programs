class mobile
{
   double m_cost;
   String m_name;
   String color;

   mobile(double x, String y, String z)
   {
     m_cost=x;
     m_name=y;
     color=z;
	
     }
     public static void main(String[] args)
     {
       mobile m1=new mobile(300.00,"redmi","red");
         System.out.println(m1.m_cost);
		 System.out.println(m1.m_name);
		 System.out.println(m1.color);

     }
 }