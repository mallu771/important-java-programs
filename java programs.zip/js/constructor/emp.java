class emp
{
   int id;
   double sal;
   char grade;
   emp(int x, double y, char z)
   {
     id=x;
     sal=y;
     grade=z;
     }
     public static void main(String[] args)
     {

       emp e1=new emp(100,30000.00,'A');
       System.out.println(e1.id);
       System.out.println(e1.sal);
       System.out.println(e1.grade);
     }
 }