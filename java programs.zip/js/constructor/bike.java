class bike
{
   double cost;
   String brand;
   String color;
   bike(double x, String y, String z)
   {
     cost=x;
     brand=y;
     color=z;
     }
     public static void main(String[] args)
     {

       bike b1=new bike(55000.40,"NS","black");
       System.out.println(b1.cost);
       System.out.println(b1.brand);
       System.out.println(b1.color);

     }
 }