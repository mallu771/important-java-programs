class Tv
{
   double cost;
   String brand;
   String type;
   Tv(double x, String y, String z)
   {
     cost=x;
     brand=y;
     type=z;
     }
     public static void main(String[] args)
     {

       Tv t1=new Tv(4000.40,"LG","Smart tv");
       System.out.println(t1.cost);
       System.out.println(t1.brand);
       System.out.println(t1.type);

     }
 }