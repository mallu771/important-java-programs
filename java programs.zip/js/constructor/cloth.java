class cloth
{
   String color;
   double cost;
   int size;
   cloth(String x, double y, int z)
   {
     color=x;
     cost=y;
     size=z;
     }
     public static void main(String[] args)
     {

       cloth c1=new cloth("red",1500.00,32*28);
       System.out.println(c1.color);
       System.out.println(c1.cost);
       System.out.println(c1.size);
     }
 }