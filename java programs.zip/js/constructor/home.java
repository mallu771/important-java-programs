class home
{
   double cost;
   String h_name;
   String color;
   home(double x, String y, String z)
   {
     cost=x;
     h_name=y;
     color=z;
     }
     public static void main(String[] args)
     {

       home h1=new home(40000.00,"god bless","yellow");
       System.out.println(h1.cost);
       System.out.println(h1.h_name);
       System.out.println(h1.color);
     }
 }