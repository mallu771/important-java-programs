class school
{
   char grade;
   int strength;
   String name;

   school(char x, int y, String z)
   {
     grade=x;
     strength=y;
     name=z;
	
     }
     public static void main(String[] args)
     {
       school s1=new school('A',100,"xyz");
         System.out.println(s1.grade);
		 System.out.println(s1.strength);
		 System.out.println(s1.name);

     }
 }