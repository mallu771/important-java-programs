class course
{
   double cost;
   String c_name;
   String unver_name;
   course(double x, String y, String z)
   {
     cost=x;
     c_name=y;
     unver_name=z;
     }
     public static void main(String[] args)
     {

       course c1=new course(50000.00,"BE","vtu");
       System.out.println(c1.cost);
       System.out.println(c1.c_name);
       System.out.println(c1.unver_name);
     }
 }