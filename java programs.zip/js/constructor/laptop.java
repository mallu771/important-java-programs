class laptop
{
   double cost;
   String l_name;
   String brand;
   laptop(double x, String y, String z)
   {
     cost=x;
     l_name=y;
     brand=z;
     }
     public static void main(String[] args)
     {

       laptop l1=new laptop(35000.00,"lenovo","hp");
       System.out.println(l1.cost);
       System.out.println(l1.l_name);
       System.out.println(l1.brand);
     }
 }