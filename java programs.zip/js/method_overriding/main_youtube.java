class youtube_v1
{
  void watch(){
  System.out.println("watch videos");
}
}
class youtube_v2 extends youtube_v1
{
  void watch()
  {
  System.out.println("watch video, reels and subtitles");
}
} 
class main_youtube
{
  public static void main(String[] args){
    youtube_v2 v2=new youtube_v2();
      v2.watch();
}
}