class projector_v1
{
  void work(){
  System.out.println("on by remote to start");
}
}
class projector_v2 extends projector_v1
{
  void work()
  {
  System.out.println("on by mobile to start");
}
} 
class main_projector
{
  public static void main(String[] args){
  projector_v2 v2=new projector_v2();
      v2.work();
}
}