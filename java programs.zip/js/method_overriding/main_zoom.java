class zoom_v1
{
  void join(){
  System.out.println("join only contect number");
}
}
class zoom_v2 extends zoom_v1
{
  void join()
  {
  System.out.println("join througth links");
}
} 
class main_zoom
{
  public static void main(String[] args){
  zoom_v2 v2=new zoom_v2();
      v2.join();
}
}