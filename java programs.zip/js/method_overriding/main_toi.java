class toi_1
{
  void status(){
  System.out.println("status with only text");
}
}
class toi_v2 extends toi_1
{
  void status()
  {
  System.out.println("status with text, images nd videos");
}
} 
class main_toi
{
  public static void main(String[] args){
    toi_v2 v2=new toi_v2();
      v2.status();
}
}