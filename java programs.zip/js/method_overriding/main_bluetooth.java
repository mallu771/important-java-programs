class bluetooth_1
{
  void music(){
  System.out.println("listen music with wire");
}
}
class bluetooth_v2 extends bluetooth_1
{
  void music()
  {
  System.out.println("listen music without wire");
}
} 
class main_bluetooth
{
  public static void main(String[] args){
     bluetooth_v2 v2=new  bluetooth_v2();
      v2.music();
}
}