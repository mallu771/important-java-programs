class mobile_currency_v1
{
  void currency(){
  System.out.println("mobile data limited");
}
}
class mobile_currency_v2 extends mobile_currency_v1
{
  void currency()
  {
  System.out.println("mobile data unlimited");
}
} 
class main_mobile_currency
{
  public static void main(String[] args){
    mobile_currency_v2 v2=new mobile_currency_v2();
      v2.currency();
}
}