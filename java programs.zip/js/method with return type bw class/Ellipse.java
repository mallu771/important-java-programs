class File
{
  static double area()
  {
    int a=3;
    int b=7;
    double res=3.142*a*b;
    return res;
    }
    }
    class Ellipse
    {
     public static void main(String[] args)
     {
       double Z=File.area();
       System.out.println(Z);
       }
       }
     