class View
{
  static int area()
  {
    int b=5;
    int h=7;
    int res=b*h;
    return res;
    }
    }
    class Parallelogram
    {
     public static void main(String[] args)
     {
       int S=View.area();
       System.out.println(S);
       }
       }
     