class Doc
{
  static double area()
  {
    int r=5;
	final double z=30.5;
    double res=0.5*r*r*z;
    return res;
    }
    }
    class Sector
    {
     public static void main(String[] args)
     {
       double V=Doc.area();
       System.out.println(V);
       }
       }
     