class Sample
{
  static int area()
  {
    int w=8;
    int h=9;
    int res=w*h;
    return  res;
    }
    }
    class Rectangle
    {
     public static void main(String[] args)
     {
       int X=Sample.area();
       System.out.println(X);
       }
       }
     