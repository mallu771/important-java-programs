class Edit
{
  static int area()
  {
    int a=5;
	int res=a*a;
    return res;
    }
    }
    class Square
    {
     public static void main(String[] args)
     {
       int M=Edit.area();
       System.out.println(M);
       }
       }
     