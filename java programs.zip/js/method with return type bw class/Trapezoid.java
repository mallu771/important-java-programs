class Test
{
  static double area()
  {
    int a=4;
    int b=6;
    int h=8;
    double res=0.5*(a+b)*h;
    return res;
    }
    }
    class Trapezoid
    {
     public static void main(String[] args)
     {
       double Y=Test.area();
       System.out.println(Y);
       }
       }
     