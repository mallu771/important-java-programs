class Demo
{
  static double area()
  {
    int b=4;
    int h=6;
    double res=0.5*b*h;
    return  res;
    }
    }
    class Triangle
    {
     public static void main(String[] args)
     {
       double A=Demo.area();
       System.out.println(A);
       }
       }
     