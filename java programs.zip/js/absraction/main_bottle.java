
  interface bottle{
	 void store();
}
 class water_bottle implements bottle{
	public void store(){
		System.out.println("store water");
	
	}
}
 class milk_bottle implements bottle{
	public void store(){
		System.out.println("store milk");
	
	}
}
 class juice_bottle implements bottle{
	public void store(){
      System.out.println("store juice");
	
	}
}
 
class storing_type {
	static void use(bottle b1)
	{
      b1.store();	
	}
}
  class main_bottle
 {
	public static void main(String[] args){
		milk_bottle m1=new milk_bottle();
		water_bottle w1=new water_bottle();
		juice_bottle j1=new juice_bottle();
		storing_type.use(m1);
		storing_type.use(w1);
		storing_type.use(j1);
	}
}

