interface cloth{
	void design();
}
 class shirt implements cloth{
	public void design(){
		System.out.println("design shirt");
	
	}
}
class Tshirt implements cloth{
	public void design(){
		System.out.println("design Tshirt");
	
	}
}
class pant implements cloth{
	public void design(){
		System.out.println("design pant");
	
	}
}
 
class industry {
	static void manufacture(cloth c1)
	{
      c1.design();	
	}
}
  class main_cloth
 {
	public static void main(String[] args){
	shirt s1=new shirt();
	Tshirt t1=new Tshirt();
	pant p1=new pant();
       industry. manufacture(s1);
       industry. manufacture(t1);

        industry. manufacture(p1);

	}
}

