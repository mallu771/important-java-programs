interface mobile{
	void operations();
}
 class vedio_player implements mobile{
  public void operations(){
		System.out.println("play vedio");
	
	}
}
class audio_speaker implements mobile{
	public void operations(){
		System.out.println("audio play");
	
	}
}
class gaming_tool implements mobile{
	public void operations(){
		System.out.println("gaming apps");
	
	}
}
 
 
class users {
	static void usage(mobile m1)
	{
      m1.operations();	
	}
}
  class main_mobile
 {
	public static void main(String[] args){
	vedio_player v1=new vedio_player();
	audio_speaker a1=new audio_speaker();
        gaming_tool g1=new gaming_tool();
	users.usage(v1);
	users.usage(a1);
	users.usage(g1);
	}
}

