interface human {
  public void emotions();
}
 class happy implements human {
     public void emotions(){
		System.out.println("happy face");
	
	}
}
 class sad implements human {
     public void emotions(){
		System.out.println("sad face");
	
	}
}
 class angry implements human {
      public void emotions(){
		System.out.println("angry face");
	
	}
}
class situation {
	static void react(human h2)
	{
      h2.emotions();
	
	}
}
  class main_human
 {
	public static void main(String[] args){
		angry a1=new angry();
		happy h1=new happy();
		sad s1=new sad();
		situation.react(a1);
		situation.react(h1);
		situation.react(s1);
		
	}
}

