class Rectangle
{
   static int area()
   {
     int w=5;
     int h=7;
     int res=w*h;
     return res;
     }

   public static void main(String[] args)
   {
          int x=area();
	   System.out.println(x);
	   }
	   }
  