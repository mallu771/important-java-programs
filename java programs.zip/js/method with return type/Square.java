class Square
{
   static int area()
   {
     int a=5;
    
     int res=a*a;
     return res;
     }

   public static void main(String[] args)
   {
          int x=area();
	   System.out.println(x);
	   }
	   }
  