class Ellipse
{
   static double area()
   {
     int a=5;
     int b=7;
     double res=3.142*a*b;
     return res;
     }

   public static void main(String[] args)
   {
          double x=area();
	   System.out.println(x);
	   }
	   }
  