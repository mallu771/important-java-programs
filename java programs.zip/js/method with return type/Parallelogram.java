class Parallelogram
{
   static int area()
   {
     int b=5;
     int h=8;
     int res=b*h;
     return res;
     }

   public static void main(String[] args)
   {
          int x=area();
	   System.out.println(x);
	   }
	   }
  