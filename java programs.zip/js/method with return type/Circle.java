class Circle
{
   static double area()
   {
     int r=5;
    
     double res=3.142*r*r;
     return res;
     }

   public static void main(String[] args)
   {
          double x=area();
	   System.out.println(x);
	   }
	   }
  