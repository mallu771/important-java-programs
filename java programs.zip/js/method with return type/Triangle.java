class Triangle
{
   static double area()
   {
     int b=5;
     int h=7;
     double res=0.5*b*h;
     return res;
     }

   public static void main(String[] args)
   {
           double x=area();
	   System.out.println(x);
	   }
	   }
  