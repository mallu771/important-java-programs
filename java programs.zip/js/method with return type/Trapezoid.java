class Trapezoid
{
   static double area()
   {
     int a=5;
     int b=7;
     int h=6;
     double res=0.5*(a+b)*h;
     return res;
     }

   public static void main(String[] args)
   {
          double x=area();
	   System.out.println(x);
	   }
	   }
  