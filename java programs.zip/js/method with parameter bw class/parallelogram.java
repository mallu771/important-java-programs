class project
{
  static void area(int b, int h)
  {
    int res=b*h;
    System.out.println(res);
    }
    }

    class parallelogram
    {
     public static void main(String[] args)
     {
        project.area(4,7);
       }
       }