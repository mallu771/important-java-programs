class Demo
{
  static void area(int w, int h)
  {
    int res=w*h;
    System.out.println(res);
    }
    }

    class Rectangle
    {
     public static void main(String[] args)
     {
       Demo.area(4,8);
       }
       }