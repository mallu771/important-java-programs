class Zc
{
  static void area(int r)
  {
    double res=0.5*r*r*30.5;
    System.out.println(res);
    }
    }

    class Sector
    {
     public static void main(String[] args)
     {
        Zc.area(5);
       }
       }