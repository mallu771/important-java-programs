class doc
{
  static void area(int a)
  {
    int res=a*a;
    System.out.println(res);
    }
    }

    class Square
    {
     public static void main(String[] args)
     {
       doc.area(6);
       }
       }