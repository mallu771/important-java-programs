class if9
{
 public static void main(String[] args)
 {  
   int a=5;
   int b=1;
  
   for(int i=1;i<=10;i++){
     if(i%2==0)
	   {
      b=a*i;
     System.out.println(b);
	   }
	} 
   } }