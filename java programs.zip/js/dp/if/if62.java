class if62
{
 public static void main(String[] args)
 {  
 
   
     
    for(int i=5;i<=15;i++)
    {
   
	if(i%2==1){
      
      System.out.println((i*i));
		}
   }
      
	
   } }