class if49
{
 public static void main(String[] args)
 {  
   for(int i=1;i<=10;i++)
	 {
	 if(i%2==0){

      System.out.println(i*3*3);
      }
      else if(i%2==1){

      System.out.println(i*3*3);
      }
	 }
   } }