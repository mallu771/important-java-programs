class if44
{
 public static void main(String[] args)
 {  

 for(int i=30;i<=50;i=i+10)
 {
   if(i%2==0)
   {
       System.out.println((2+i)-(2*15)); 
     
      }
 else if(i%2==1)
   {
      System.out.println((2+i)-(2*15)); 
      }

  }

   } }