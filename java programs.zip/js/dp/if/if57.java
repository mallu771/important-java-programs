class if57
{
 public static void main(String[] args)
 {  
	 int a=8;
   int b=1;
    for(int i=1;i<=8;i++)
    {
     if(i%2==1){
        b=a*b;
      System.out.println(b);
   }
  
      }
	
   } }