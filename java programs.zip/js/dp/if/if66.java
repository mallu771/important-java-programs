class if66
{
 public static void main(String[] args)
 {  
 
   
     
    for(int i=0;i<=10;i=i+2)
    {
   
	
		if(i%2==0){
      
      System.out.println(i*(i-5));
		}
   }
      
	
   } }