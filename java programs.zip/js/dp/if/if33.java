class if33
{
 public static void main(String[] args)
 {  
 
 
   int i=10;
     if(i%2==0)
     {
      System.out.println("hii");
  
     
      }
	 else if(i%2==1)
     {
      System.out.println("hello");
      }
   
   
  
   } }