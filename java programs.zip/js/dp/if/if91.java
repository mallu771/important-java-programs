class if91
{
 public static void main(String[] args)
 {  
    int j=10;
    for(int i=1;i<=5;i++)
    {
      if(i%2==1){
      System.out.println((i*i)+" "+(j+2));
	j=j+10;
		}
	else if(i%2==0){
      System.out.println((i*i)+" "+(j+2));
	j=j+10;
		}
   }} }
