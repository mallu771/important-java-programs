class if13
{
 public static void main(String[] args)
 {  
    int a=4;
   for(int i=1;i<=10;i++){
   if(i%2==0)
   {
	   a=a*2;
     System.out.println(a);
	   }
  
   } }}