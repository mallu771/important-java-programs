class if99
{
 public static void main(String[] args)
 {  
   
    for(int i=2;i<=10;i++)
    {
       if(i%2==1){
	
      System.out.println((i*2)-5);
	}
	if(i%2==0){
	
      System.out.println((2*i)-5);
	}
		}
		  
	
   }} 