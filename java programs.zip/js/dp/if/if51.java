class if51
{
 public static void main(String[] args)
 {  
   for(int i=0;i<13;i++)
	 {
	 if(i%2==0){

      System.out.println(i);
      }
      else if(i%2==1){

      System.out.println(i);
      }
	 }
   } }