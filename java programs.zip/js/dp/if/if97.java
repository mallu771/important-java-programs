class if97
{
 public static void main(String[] args)
 {  
   int a=2;
   int b=1;
    for(int i=1;i<=10;i++)
    {
       
	b=a*b;
      System.out.println(b);
	
		}
		  
	
   }} 