class if45
{
 public static void main(String[] args)
 {  
 
   int i=1;
   for(int j=5;j<=9;j++)
	 {
      System.out.println(j);
	  System.out.println(i);
	     i++;
	 }
	  
  
   } }