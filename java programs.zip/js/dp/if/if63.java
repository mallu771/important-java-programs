class if63
{
 public static void main(String[] args)
 {  
 
   
     
    for(int i=8;i>=4;i--)
    {
   
	if(i%2==1){
      
      System.out.println((i*i)+5);
		}
		else if(i%2==0){
      
      System.out.println((i*i)+5);
		}
   }
      
	
   } }