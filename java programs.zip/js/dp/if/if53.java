class if53
{
 public static void main(String[] args)
 {    
     int i=10;
  
	 if(i%2==0){

      System.out.println("#java");
      }
      if(i%2==1){

      System.out.println("#mava");
      }
	 
   } }