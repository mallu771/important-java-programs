class if78
{
 public static void main(String[] args)
 {  
 
   
     int a=4;
     int b=1;
    for(int i=1;i<=5;i++)
    {
   
	b=b*a;
		
      
      System.out.println(b);
		}
	
   } }