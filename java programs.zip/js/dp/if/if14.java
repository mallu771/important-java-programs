class if14
{
 public static void main(String[] args)
 {  
    int j=2;
   for(int i=1;i<=5;i++){
   
     System.out.println((i*i)+j);
     j++;
	
  
   } }}