class if88
{
 public static void main(String[] args)
 {  
  
    for(char ch='A';ch<='Z';ch++)
    {
      if(ch%2==1){
      System.out.println(ch);
	
		}
	else if(ch%2==0){
      System.out.println(ch);
	
		}
   }} }