class if41
{
 public static void main(String[] args)
 {  
  int a=8;
  int b=1;
 for(int i=1;i<=100;i++)
 {
      b=a*b;
      System.out.println(b);
  }
  
   } }