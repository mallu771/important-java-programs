class if87
{
 public static void main(String[] args)
 {  
    int j=0;
    for(int i=1;i<=10;i++)
    {
      if(i%2==1){
      System.out.println((i*j));
	  j=j+2;
		}
	
   }} }