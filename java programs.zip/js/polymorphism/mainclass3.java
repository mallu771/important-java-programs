
 class mobile{
	void operations(){
		System.out.println("operations");
	
	}
}
 class vedio_player extends mobile{
	void operations(){
		System.out.println("play vedio");
	
	}
}
class audio_speaker extends mobile{
	void operations(){
		System.out.println("audio play");
	
	}
}
class gaming_tool extends mobile{
	void operations(){
		System.out.println("gaming apps");
	
	}
}
 
 
class users {
	static void usage(mobile m1)
	{
      m1.operations();	
	}
}
  class mainclass3
 {
	public static void main(String[] args){
	vedio_player v1=new vedio_player();
	audio_speaker a1=new audio_speaker();
        gaming_tool g1=new gaming_tool();
	users.usage(v1);
	users.usage(a1);
	users.usage(g1);
	}
}

