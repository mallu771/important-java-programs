
 class class_room{
	void environment(){
		System.out.println("learn something");
	
	}
}
 class comic extends class_room{
	void environment(){
		System.out.println("comic story");
	
	}
}
class study extends class_room{
	void environment(){
		System.out.println("study ");
	
	}
}
class presentation extends class_room{
	void environment(){
		System.out.println("presentation");
	
	}
}

 
class students {
	static void behaviour(class_room c2)
	{
      c2.environment();	
	}
}
  class mainclass4
 {
	public static void main(String[] args){
	comic c1=new comic();
	study s1=new study();
        presentation p1=new presentation();
	students.behaviour(c1);
	students.behaviour(s1);
	students.behaviour(p1);
	}
}

