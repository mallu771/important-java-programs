class demo5
{
  public static void main(String[] args)
  {  
   
   for(int i=1;i<=10/2;i++)

{
      System.out.println("4*"+i+"="+i);
      }
	  
      }
      }
