class sample4
{
  public static void main(String[] args)
  {
    for(int i=1;i<=7;i++)
    {
      System.out.println("2"+"x"+i+"="+(2*i+1));
      }
      }
      }