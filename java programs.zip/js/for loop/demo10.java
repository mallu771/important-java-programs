class demo10
{
  public static void main(String[] args)
  {  
   
   for(int i=2;i<=5;i++)
   {
	System.out.println(((2*i)*(2*i)*(2*i))-1);
	 }
	 }
	 }