class demo7
{
  public static void main(String[] args)
  {  
   
   for(int i=1;i<=4;i++)
   {
	  
      System.out.println("3*"+i+"="+((3*i)+9)/3);

      }
	  
      }
      }
