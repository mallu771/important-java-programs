class demo30
{
  public static void main(String[] args)
  {  
    int j=1;
   for(int i=1; i<=5;i++)
     { 
      if(j<=5)
      {
      System.out.println((i*i)+" "+j);
	}
	j++;

	}
  }
}