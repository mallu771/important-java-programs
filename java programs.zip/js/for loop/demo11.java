class demo11
{
  public static void main(String[] args)
  {  
   
   for(int i=2;i<=10;i=i+2)
   {
	System.out.println((i*i*i));
	 }
	 }
	 }