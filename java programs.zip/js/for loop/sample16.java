class sample16
{
  public static void main(String[] args)
  {  
	 
    for(int i=10;i>=2;i--)
    {
	  System.out.println(i-1);
      }
      }
	  }