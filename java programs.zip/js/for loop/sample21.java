class sample21
{
  public static void main(String[] args)
  {  
     
    for(int i=1;i<=5;i++)
    {
		int j=2;
        if(i%2==0 & j%2==1)
	{
	  System.out.println(i*j);
	  j++;
	 
      }
      }
	  }
	  }