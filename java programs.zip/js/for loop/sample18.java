class sample18
{
  public static void main(String[] args)
  {  
	int j=10;
    for(int i=1;i<=10;i++)
    {
      if(j>=4&i<=7){
	  System.out.println(i+"*"+j+"="+(i*j));
	  j--;
	  }
      }
      }
	  }