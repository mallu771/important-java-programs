class demo1
{
  public static void main(String[] args)
  {  
    int j=10;
    for(int i=2;i<=10;i=i+2)
    {
	  System.out.println("hello");
      System.out.println(+i+"*"+j+"="+(i*j));
	   j--;
	  System.out.println("hello");
	
      }
      }
	  }
	  