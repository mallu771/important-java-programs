class sample26
{
  public static void main(String[] args)
  {  
    
    for(int i=1;i<=4;i++)
    {
	  System.out.println((1/2)*i);
	 
      }
      }
	  }
	  