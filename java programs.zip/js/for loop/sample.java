class sample
{
  public static void main(String[] args)
  {
    for(int i=1;i<=10;i=i+2)
    {
    
	  System.out.println("2"+"*"+i+"="+(2*i*4-1));
      }
      }
      }