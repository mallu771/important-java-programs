class demo22
{
  public static void main(String[] args)
  {  
   
   for(int i=0;i<=4;i++)
   {  
     
	System.out.println(i);
   }
    for(int j=0;j<=4;j++)
   {  
     
	System.out.println(j);
   }
    for(int k=0;k<=4;k++)
   {  
     
	System.out.println(k);
   }
  }
	 }
	 