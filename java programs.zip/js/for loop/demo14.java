class demo14
{
  public static void main(String[] args)
  {  
  
   for(int i=30;i<=50;i=i+10)
   {  
     
	System.out.println((2+i)-(2*15));
	 }
	 }
	 }