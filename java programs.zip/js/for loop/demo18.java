class demo18
{
  public static void main(String[] args)
  {  
   
   for(double i=1;i<=2;i++)
   {  
     
	System.out.println(i/2);
   }
	 
	 }
	 }