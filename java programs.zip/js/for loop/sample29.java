class sample29
{
  public static void main(String[] args)
  {  
    
    for(int i=5;i<=8;i++)
    {
	  System.out.println(+i+"*3"+"="+(i*3)/3);
	 
      }
      }
	  }
	  