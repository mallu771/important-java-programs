class demo3
{
  public static void main(String[] args)
  {  
   
    int i=2;
		if(i%2==0)
		{
      System.out.println("hii");
      }
      else{
        
	 System.out.println("hello");
	
      }
      }
	  }
