class demo6
{
  public static void main(String[] args)
  {  
    int j=2;
   for(int i=1;i<=4;i=i+1)

{
	
      System.out.println((i*i)*j);
      j++;
      }
	  
      }
      }
