class demo8
{
  public static void main(String[] args)
  {  
   int a[3]={20,56,70};
   b=a[0];
   for(int i=0;i<=a.length();i++)
   {
	if(a[i]>b)
	{
	 b=a[i];
	 }
	 }

      System.out.println(b);
      c=a[0];
for(int i=0;i<=a.length();i++)
   {
	if(c>a[i]>b)
	{
	 c=a[i];
	 }
	 }

      System.out.println(c);
	  
      }
      }
