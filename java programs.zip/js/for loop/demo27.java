class demo27
{
  public static void main(String[] args)
  {  
    int a=8;
    int b=1;
   for(int i=1; i<=a;i++)
     { 
	   b=b*a;

	   System.out.print(b+" ");
		 }
	}

	}