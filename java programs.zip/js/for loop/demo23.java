class demo23
{
  public static void main(String[] args)
  {  
   
    int i=2;
     if(i%2==0)
     {
    
	System.out.println("#java");
  
   }
   
   else{
      System.out.println("#mava");
   
   }
	 }
	 }