class sample8
{
  public static void main(String[] args)
  {  
	 
    for(int i=1;i<=4;i++)
    {
     
	  System.out.println("5"+"*"+i+"="+((5*i)*(i*5)));
      }
      }
	  }