class demo2
{
  public static void main(String[] args)
  {  
   
    for(int i=1;i<=10/2;i++)
    {
      System.out.println((i*i));
	
	
      }
      }
	  }
	  