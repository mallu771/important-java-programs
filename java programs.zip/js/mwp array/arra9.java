class arra9
{
  
   
 static void array(int[] arr){
    int mul=1;

     for(int i=1;i<arr.length;i++){
    
      mul=mul*(arr[i]*arr[i]);


     
     }
System.out.println(mul);
     }
     

 public static void main(String[] args)
 {  
   int[] arr={1,2,3,4,5,6,7,8,9,10};
   array(arr);
	
          
		   
	}
   
	}
	
    
	
     